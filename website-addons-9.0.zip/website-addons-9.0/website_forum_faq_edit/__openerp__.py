{
    'name': "Website forum edit faq",
    'version': '1.0.0',
    'author': 'Salton Massally',
    'category': 'Website',
    'website': 'idtlabs.sl',
    'depends': ['website_forum'],
    'data': [
        'views.xml',
        ],
    'auto_install': True,
    'installable': False
}
