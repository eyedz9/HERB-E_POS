Web Login Background
====================

Set your background picture on odoo login and signup screens.

Tested on Odoo 9.0 4dbc81f910d872ddb48d855396fcc7d91ddc9410
