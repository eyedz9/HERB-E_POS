{
    'name' : 'Resource booking calendar Public',
    'version' : '0.1',
    'author' : 'IT-Projects LLC, Veronika Kotovich',
    'license': 'LGPL-3',
    'website' : 'https://twitter.com/vkotovi4',
    'category' : 'Website',
    'depends' : ['booking_calendar', 'website_sale'],
    'data': ['views.xml'],
    'installable': False
}
