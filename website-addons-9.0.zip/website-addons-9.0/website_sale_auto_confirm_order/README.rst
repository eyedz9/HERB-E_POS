eCommerce: autoconfirm order
============================

Sale order will be confirmed after user clicks "Pay Now" (for wired transfer).

Tested on Odoo 8.0 78a20a3dba07762d2de1e22072c20be1bc59d20f
