{
    'name': "eCommerce: autoconfirm order",
    'version': '1.0.0',
    'author': 'IT-Projects LLC, Ivan Yelizariev',
    'license': 'LGPL-3',
    'category': 'Custom',
    'website': 'https://yelizariev.github.io',
    'depends': ['website_sale'],
    'data': [
        'views.xml',
        ],
    'installable': False,
}
