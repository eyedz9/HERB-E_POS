Sale only available products on Website
=======================================

Tested on Odoo 8.0 6682bde8a202794740b9756542b5b119db7606f3
