Website Login Background
========================

Set your background on odoo login and signup screens while you got website module installed.

Tested on Odoo 8.0 7b7f3fa76a822f05283e36b40bdbc58793f84570
