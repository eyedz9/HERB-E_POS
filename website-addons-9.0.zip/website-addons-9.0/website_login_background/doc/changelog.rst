.. _changelog:

Changelog
=========

`1.0.1`
-------

- IMP: Padding for signup page

`1.0.0`
-------

- init version
