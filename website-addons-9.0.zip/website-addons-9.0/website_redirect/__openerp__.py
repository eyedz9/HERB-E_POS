{
    'name': "Page redirections",
    'version': '1.0.0',
    'author': 'IT-Projects LLC, Ivan Yelizariev',
    'license': 'LGPL-3',
    'category': 'Custom',
    'website': 'https://yelizariev.github.io',
    'depends': ['website'],
    'data': [
        'website_redirect_views.xml',
        ],
    'installable': False
}
