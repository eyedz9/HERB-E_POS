Sale limited and private products on Website
============================================

Module makes it impossible to define limit for products and assign private products to any customers.

Portal user is unable to buy more then limited quantity of product and private products of other customers.

Added tab "Private products" to customer form.

Added new options on tab "Sales" of product form.

If decide to uninstall this module, please update module "website_sale" to reset ir.rule for product access

Tested on Odoo 8.0 78a20a3dba07762d2de1e22072c20be1bc59d20f
