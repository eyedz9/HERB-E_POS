Custom website search
=====================

* product search is made to be global to all products no matter what category the person is in at the time.
* clear the search if the person clicks on any category link so the results are not filtered anymore.
* adds results from searching by tags

WARNING
-------

Due to odoo restriction, this module should be installed on all databases in odoo instance.

Tested on Odoo 9.0 04c6ee54d86013bc2995778f62074115c1bd9ed3
