After customer make an online payment (e.g. via paypal), new invoice is created and validated.

Tested on Odoo 9.0 bdfc75e613b45afcc5e9ada58f2d6c3d42b7732a
