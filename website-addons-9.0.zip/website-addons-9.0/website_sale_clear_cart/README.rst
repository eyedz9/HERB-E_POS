Clear cart button
=================

Description: https://apps.odoo.com/apps/modules/8.0/website_sale_clear_cart

Tested on Odoo 8.0 f8d5a6727d3e8d428d9bef93da7ba6b11f344284.
