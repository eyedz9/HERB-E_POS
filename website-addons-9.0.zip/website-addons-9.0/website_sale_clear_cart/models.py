from openerp import api,models,fields
