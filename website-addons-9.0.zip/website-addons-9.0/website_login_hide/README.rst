Hide the "Sign in" button in Website
=============================================

Hides the "Sign in" button in Website.

Tested on 9.0 2ec9a9c99294761e56382bdcd766e90b8bc1bb38
