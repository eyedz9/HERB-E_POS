from openerp import api, models, fields, SUPERUSER_ID
