Adds "New" Ribbon (like "Sale").

Adds automatic ribbons:

* DISCONTINUED --  stock is 0 and the status is End of Life or Obsolete.
* BACKORDERED -- stock is 0 and the status is Normal,

Puts ribbons text at the product page.

Disables "Add to cart" feature if product is discontinued.

Tested on Odoo 8.0 f8d5a6727d3e8d428d9bef93da7ba6b11f344284.

Further information and discussion: http://yelizariev.github.io/odoo/module/2015/02/20/ecommerce-stock-status.html
