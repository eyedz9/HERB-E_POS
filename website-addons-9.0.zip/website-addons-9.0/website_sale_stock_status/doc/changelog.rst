1.0.1
=====

* [FIX] disable add_to_cart at /shop (it was done only at product page)
