Add birthdate field to website_sale checkout form
=================================================

Module depends on partner_person module which you can find at https://github.com/ingadhoc/odoo-addons

You should make sure that you activated 'Partner Person Birthdate' option in Settings\\Users\\Users.

Tested on Odoo 8.0 1d5651de5da533139d5a24a5aa6852b765cd73ca
